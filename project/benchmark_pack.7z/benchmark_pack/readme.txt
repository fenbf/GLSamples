persistent_run_test.bat [triangle count] - runs persitance mapped buffer tests
standard_run_test.bat [triangle count] - runs standard mapped/updated buffers
run_all_tests.bat [triangle count] - runs both of the above tests at once
run_from_10_to_5000.bat - runs the benchmark for 10, 100, 1000, 2000 and 5000 tris

additional option: pass "resonly=true" to apps so than only results info will be presented (less output)

bfilipek.com